************************************
***                              ***
*** QuickSMS v107 Beta installer ***
***                              ***
************************************

For Set Up the program following to steps :

1 - Extract Zip package to a folder
2 - Righ clik to QuickSMSInstaller.exe
3 - Select Run As Administrator
4 - Close to installer 

PLEASE NOTE !!! 

The Installer will create a folder on your DESKTOP and register the components, then 

you can clik the "QuickSMS ICON ON YOUR DESKTOP" for the run QuickSMS.

Usage informations are founded on the Program Help Menu.

Support : quicksms2023@gmail.com

Regards...