QuickSMS v106 Beta installer :

For Set Up the program following to steps :

1 - Extract Zip package to a folder
2 - Righ clik to QuickSMSInstaller.exe
3 - Select Run As Administrator
4 - Close installer

Installer will make folder on desktop and register the components, 
then you can clik the program icon to run it. 

Usage informations are founded on the Program Help Menu.

Support : quicksms2023@gmail.com
